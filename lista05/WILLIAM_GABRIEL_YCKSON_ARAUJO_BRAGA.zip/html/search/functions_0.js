var searchData=
[
  ['configurarfila_0',['configurarFila',['../q1__documentado_8c.html#a51a754992e423c96dda6e87de6db5234',1,'q1_documentado.c']]],
  ['criarcliente_1',['criarCliente',['../q1__documentado_8c.html#a20257b45a4784b0123e3ba1e336dadfa',1,'q1_documentado.c']]]
];
