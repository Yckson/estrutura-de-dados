var indexSectionsWithContent =
{
  0: "cfimnqrt",
  1: "cf",
  2: "q",
  3: "cfimr",
  4: "cfimnt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Estruturas de dados",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis"
};

