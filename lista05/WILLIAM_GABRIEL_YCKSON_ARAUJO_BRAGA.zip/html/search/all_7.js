var searchData=
[
  ['tamanho_0',['tamanho',['../struct_fila.html#a46bbd844d92a49df2f9f1dff542301db',1,'Fila']]],
  ['tempo_5fatendimento_1',['TEMPO_ATENDIMENTO',['../q1__documentado_8c.html#a93507e5bea501a870947a21231a300a8',1,'q1_documentado.c']]],
  ['tempodeatendimento_2',['tempoDeAtendimento',['../struct_cliente.html#a8bfaa4b4ae8177e1420aed018fc87157',1,'Cliente']]]
];
