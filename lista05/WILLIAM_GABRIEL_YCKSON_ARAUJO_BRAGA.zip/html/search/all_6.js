var searchData=
[
  ['removercliente_0',['removerCliente',['../q1__documentado_8c.html#a4698a20a75c4b7fd7c7a43b7342440b1',1,'q1_documentado.c']]]
];
