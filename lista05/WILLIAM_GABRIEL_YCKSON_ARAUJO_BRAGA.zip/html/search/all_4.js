var searchData=
[
  ['nome_0',['nome',['../struct_cliente.html#a98e7bbb6e7d2fe395c13ea9b09440e81',1,'Cliente']]]
];
