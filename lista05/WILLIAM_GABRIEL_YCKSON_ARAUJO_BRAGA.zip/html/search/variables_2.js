var searchData=
[
  ['inicio_0',['inicio',['../struct_fila.html#a147d2dab337001584b42f25acc83dbc4',1,'Fila']]]
];
