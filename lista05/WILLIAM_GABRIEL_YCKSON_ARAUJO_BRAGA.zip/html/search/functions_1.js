var searchData=
[
  ['filacheia_0',['filaCheia',['../q1__documentado_8c.html#a733a3dbba543bfb95cdfe0a46464677b',1,'q1_documentado.c']]],
  ['filavazia_1',['filaVazia',['../q1__documentado_8c.html#ac5b5cbdc91bdd98006d0c919208026b6',1,'q1_documentado.c']]]
];
