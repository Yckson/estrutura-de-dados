var searchData=
[
  ['fila_0',['Fila',['../struct_fila.html',1,'']]],
  ['filacheia_1',['filaCheia',['../q1__documentado_8c.html#a733a3dbba543bfb95cdfe0a46464677b',1,'q1_documentado.c']]],
  ['filavazia_2',['filaVazia',['../q1__documentado_8c.html#ac5b5cbdc91bdd98006d0c919208026b6',1,'q1_documentado.c']]],
  ['fim_3',['fim',['../struct_fila.html#a0bfa61e4420339260531a5a5cb22b4a2',1,'Fila']]]
];
