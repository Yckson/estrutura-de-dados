var searchData=
[
  ['cliente_0',['Cliente',['../struct_cliente.html',1,'']]],
  ['clientes_1',['clientes',['../struct_fila.html#ac2f43f69f806b01ca41a441a14e80452',1,'Fila']]],
  ['cod_2',['cod',['../struct_cliente.html#a986d2ec973185d7d326c7eb75add174b',1,'Cliente']]],
  ['configurarfila_3',['configurarFila',['../q1__documentado_8c.html#a51a754992e423c96dda6e87de6db5234',1,'q1_documentado.c']]],
  ['criarcliente_4',['criarCliente',['../q1__documentado_8c.html#a20257b45a4784b0123e3ba1e336dadfa',1,'q1_documentado.c']]]
];
