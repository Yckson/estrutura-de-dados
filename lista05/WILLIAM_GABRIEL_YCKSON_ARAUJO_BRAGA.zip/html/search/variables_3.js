var searchData=
[
  ['max_5ffila_0',['MAX_FILA',['../q1__documentado_8c.html#a11df40282f66641fdd5d139a3b454ec2',1,'q1_documentado.c']]]
];
