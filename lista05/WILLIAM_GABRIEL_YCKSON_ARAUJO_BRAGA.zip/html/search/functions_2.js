var searchData=
[
  ['imprimircliente_0',['imprimirCliente',['../q1__documentado_8c.html#a26dc126dac89e6d6f7822bcd9119400a',1,'q1_documentado.c']]],
  ['imprimirfila_1',['imprimirFila',['../q1__documentado_8c.html#a74719ec6615fa8e2f293fcad89a5f8e3',1,'q1_documentado.c']]],
  ['inserircliente_2',['inserirCliente',['../q1__documentado_8c.html#a0c376637d5ca64aeb00ac6d408cdd14b',1,'q1_documentado.c']]]
];
